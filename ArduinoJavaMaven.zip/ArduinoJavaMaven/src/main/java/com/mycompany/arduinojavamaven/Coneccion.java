/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.arduinojavamaven;

import com.panamahitek.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import jssc.*;

/**
 *
 * @author Ce
 */
public class Coneccion /*extends javax.swing.JFrame*/ {

    static private PanamaHitek_Arduino ph = new PanamaHitek_Arduino();
    static final SerialPortEventListener events = new SerialPortEventListener() {
        @Override
        public void serialEvent(SerialPortEvent spe) {
        try{
        if(ph.isMessageAvailable()){
        System.out.println(ph.isMessageAvailable());
                 }
        }   catch (SerialPortException ex) {
                Logger.getLogger(Coneccion.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ArduinoException ex) {
                Logger.getLogger(Coneccion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    };
    
    String puerto = "COM10";
    static SerialPort serialPort;

    public void openPorts() throws SerialPortException {
       
        serialPort = new SerialPort(puerto);
        serialPort.openPort();
        serialPort.setParams(9600, 8, 1, 0);
        throw new SerialPortException("asdas","adas","dasda");
    }

    public Coneccion() throws ArduinoException, SerialPortException {
//        initComponents();
        try{
            ph.arduinoRX(puerto, 9600, events);
    }catch(ArduinoException AE){
     System.out.println("fallo al crear la conexion");
    }
}
}