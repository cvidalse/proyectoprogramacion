/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.arduinojavamaven;

import java.util.ArrayList;

/**
 *
 * @author Ce
 */
public class Estacionamiento {

    ArrayList<Lote> parte = new ArrayList<>();

    public Estacionamiento() {
        add();
    }

    public String getColor(int pos) {
        boolean estado = parte.get(pos).getEstado();
        String color;
        if (estado) {
           color = "rojo";
            return color;
        } else {
            color = "verde";
            return color;
        }

    }

    public void actualizarEstado(int pos, int valorConexion) {
//        System.out.println("actualizando estado");
        parte.get(pos).setEstado(valorConexion);
    }

    private void add() {
        parte.add(new Lote());

    }

}
